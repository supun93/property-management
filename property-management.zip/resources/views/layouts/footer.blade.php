<footer class="main-footer text-sm">
  <strong>&copy; {{ date('Y') }} {{ config('app.name') }}.</strong> All rights reserved.
</footer>
