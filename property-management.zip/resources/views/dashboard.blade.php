@extends('layouts.app')

@section('content')
  <h1>Dashboard</h1>
  <p>You're logged in!</p>
@endsection